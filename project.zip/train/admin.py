from django.contrib import admin
from .models import ExistTrains, City

admin.site.register(ExistTrains)
admin.site.register(City)
